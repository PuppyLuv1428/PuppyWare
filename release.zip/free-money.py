import ctypes
import os
import time
import random
import pygame
import win32gui
import win32con
import win32api
import win32ui
import keyboard
import tkinter as tk
from PIL import Image, ImageTk
import win32com.client

# -- Wallpaper swap --
def set_wallpaper():
    path = os.path.abspath("desktop.bmp")
    ctypes.windll.user32.SystemParametersInfoW(20, 0, path, 3)

# -- Music playback --
def play_song():
    pygame.mixer.init()
    pygame.mixer.music.load("song.mp3")
    pygame.mixer.music.play(-1)

# -- BSOD intro --
def show_bsod_then_destroy():
    root = tk.Tk()
    root.attributes("-fullscreen", True)
    root.attributes("-topmost", True)
    root.configure(bg="black")
    root.overrideredirect(True)

    img = Image.open("bsod.png")
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    img = img.resize((screen_width, screen_height), Image.LANCZOS)
    photo = ImageTk.PhotoImage(img)

    label = tk.Label(root, image=photo)
    label.pack()

    root.update()
    time.sleep(7)
    root.destroy()

# -- Screen inversion pulse --
def invert_screen():
    hdc = win32gui.GetDC(0)
    width = win32api.GetSystemMetrics(0)
    height = win32api.GetSystemMetrics(1)
    win32gui.BitBlt(hdc, 0, 0, width, height, hdc, 0, 0, win32con.NOTSRCCOPY)
    win32gui.ReleaseDC(0, hdc)

# -- Fake error popup --
def spawn_fake_window():
    shell = win32com.client.Dispatch("WScript.Shell")
    shell.Popup("System Error: PuppyWare Overload", 1, "Critical Alert", 0x10)

# -- Cursor jitter --
def jitter_cursor():
    x, y = win32api.GetCursorPos()
    dx = random.randint(-50, 50)
    dy = random.randint(-50, 50)
    win32api.SetCursorPos((x + dx, y + dy))

# -- GDI chaos loop --
def gdi_rage_loop():
    hdc = win32gui.GetDC(0)
    hdc_ui = win32ui.CreateDCFromHandle(hdc)
    last_invert = time.time()
    last_popup = time.time()
    cursor_mode = 0

    try:
        while not keyboard.is_pressed("\\"):
            # -- Cursor Chaos --
            x, y = win32api.GetCursorPos()
            cursor_mode = (cursor_mode + 1) % 3
            if cursor_mode == 0:
                win32api.SetCursorPos((x + random.randint(-50, 50), y + random.randint(-50, 50)))
            elif cursor_mode == 1:
                win32api.SetCursorPos((x + 30, y - 30))
            else:
                win32api.SetCursorPos((x - 30, y + 30))

            # -- Ellipse Spam --
            for _ in range(10):
                x1 = random.randint(0, 1920)
                y1 = random.randint(0, 1080)
                x2 = x1 + random.randint(20, 100)
                y2 = y1 + random.randint(20, 100)
                brush = win32gui.CreateSolidBrush(win32api.RGB(random.randint(0,255), random.randint(0,255), random.randint(0,255)))
                win32gui.SelectObject(hdc, brush)
                win32gui.Ellipse(hdc, x1, y1, x2, y2)
                win32gui.DeleteObject(brush)

            # -- Rectangle Flickers --
            for _ in range(8):
                x1 = random.randint(0, 1920)
                y1 = random.randint(0, 1080)
                x2 = x1 + random.randint(10, 100)
                y2 = y1 + random.randint(10, 100)
                brush = win32gui.CreateSolidBrush(win32api.RGB(random.randint(0,255), random.randint(0,255), random.randint(0,255)))
                win32gui.FillRect(hdc, (x1, y1, x2, y2), brush)
                win32gui.DeleteObject(brush)

            # -- Mouse trail spam --
            mx, my = win32api.GetCursorPos()
            hdc_ui.SetTextColor(win32api.RGB(255, 0, 0))
            try:
                hdc_ui.TextOut(mx, my, ".")
            except:
                pass  # Ignore if TextOut fails

            # -- Pixel Trash (safe fallback) --
            for _ in range(20):
                px = random.randint(0, 1920)
                py = random.randint(0, 1080)
                color = win32api.RGB(random.randint(0,255), random.randint(0,255), random.randint(0,255))
                try:
                    win32gui.SetPixel(hdc, px, py, color)
                except:
                    pass  # Skip if SetPixel fails

            # -- Invert screen every 2 seconds --
            if time.time() - last_invert > 2:
                invert_screen()
                last_invert = time.time()

            # -- Popup every 5 seconds --
            if time.time() - last_popup > 5:
                spawn_fake_window()
                last_popup = time.time()

            time.sleep(0.01)
    finally:
        hdc_ui.DeleteDC()
        win32gui.ReleaseDC(0, hdc)
        pygame.mixer.music.stop()

# -- Launch sequence --
set_wallpaper()
show_bsod_then_destroy()
play_song()
time.sleep(1)
gdi_rage_loop()
