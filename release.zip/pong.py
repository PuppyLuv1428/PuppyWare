import pygame
import sys

# -- Init --
pygame.init()
WIDTH, HEIGHT = 800, 600
WIN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Puppy Pong")

WHITE = (255, 255, 255)
RED = (255, 0, 0)
BG = (30, 30, 30)
FONT = pygame.font.SysFont("Comic Sans MS", 40)

# -- Game Objects --
PADDLE_WIDTH, PADDLE_HEIGHT = 10, 100
BALL_SIZE = 20
ball_speed_x, ball_speed_y = 5, 5

left_paddle = pygame.Rect(50, HEIGHT//2 - PADDLE_HEIGHT//2, PADDLE_WIDTH, PADDLE_HEIGHT)
right_paddle = pygame.Rect(WIDTH - 60, HEIGHT//2 - PADDLE_HEIGHT//2, PADDLE_WIDTH, PADDLE_HEIGHT)
ball = pygame.Rect(WIDTH//2 - BALL_SIZE//2, HEIGHT//2 - BALL_SIZE//2, BALL_SIZE, BALL_SIZE)

score_left = 0
score_right = 0

# -- Game Loop --
clock = pygame.time.Clock()
while True:
    WIN.fill(BG)

    # -- Events --
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    # -- Input --
    keys = pygame.key.get_pressed()
    if keys[pygame.K_w] and left_paddle.top > 0:
        left_paddle.y -= 7
    if keys[pygame.K_s] and left_paddle.bottom < HEIGHT:
        left_paddle.y += 7
    if keys[pygame.K_UP] and right_paddle.top > 0:
        right_paddle.y -= 7
    if keys[pygame.K_DOWN] and right_paddle.bottom < HEIGHT:
        right_paddle.y += 7

    # -- Ball Movement --
    ball.x += ball_speed_x
    ball.y += ball_speed_y

    # -- Collisions --
    if ball.top <= 0 or ball.bottom >= HEIGHT:
        ball_speed_y *= -1

    if ball.colliderect(left_paddle) or ball.colliderect(right_paddle):
        ball_speed_x *= -1

    # -- Scoring --
    if ball.left <= 0:
        score_right += 1
        ball.center = (WIDTH//2, HEIGHT//2)
        ball_speed_x *= -1
    if ball.right >= WIDTH:
        score_left += 1
        ball.center = (WIDTH//2, HEIGHT//2)
        ball_speed_x *= -1

    # -- Draw Everything --
    pygame.draw.rect(WIN, WHITE, left_paddle)
    pygame.draw.rect(WIN, WHITE, right_paddle)
    pygame.draw.ellipse(WIN, RED, ball)
    pygame.draw.aaline(WIN, WHITE, (WIDTH//2, 0), (WIDTH//2, HEIGHT))

    score_text = FONT.render(f"{score_left}   {score_right}", True, WHITE)
    WIN.blit(score_text, (WIDTH//2 - score_text.get_width()//2, 20))

    pygame.display.flip()
    clock.tick(60)